package main.java;

interface PersonInterface {
      
	int getAge(); 
    void setAge(int new_age);
	String getName();     
    void setName(String new_name);   
    double getSalary();    
    void setSalary(double new_salary);
    double calculateBonus();    
    String becomeJudge();    
    int timeWarp();    
    int wasteTime();
}
