JUnit: TestPerson.java
Interface: PersonInterface.java